def is_mutant(dna):#metodo para analizar si es mutante o no
    cont =0
    print("------------MOSTRAR-ADN------------")#muestra la matriz 
    for i in dna:
        print(i)
    print("------------HORIZONTAL-------------")#analiza si hay coincidencias de forma horizontal
    for f in range(6):
        for c in range(6):
            if c <3:
                if dna[f][c] == dna[f][c+1] and dna[f][c] == dna[f][c+2] and dna[f][c] == dna[f][c+3]:
                    print(f"{dna[f][c]} {dna[f][c+1]} {dna[f][c+2]} {dna[f][c+3]}")#mostrar coincidencia como referencia
                    print("hay coincidencia..")
                    cont+=1
                    break
    print("------------VERTICAL-------------")#analiza si hay coincidencias de forma vertical
    for f in range(6):
        for c in range(6):
            if c <3:
                if dna[c][f] == dna[c+1][f] and dna[c][f] == dna[c+2][f] and dna[c][f] == dna[c+3][f]:
                    print(f"{dna[c][f]}\n{dna[c+1][f]}\n{dna[c+2][f]}\n{dna[c+3][f]}")#mostrar coincidencia como referencia
                    print("hay coincidencia..")
                    cont+=1
                    break
    print("------------DIAGONAL-------------")#analiza si hay coincidencias de forma diagonal
    l = []
    for f in range(3):
        for c in range(3):
            if f in l and c in l:
                continue
            if dna[f][c] == dna[f+1][c+1] and dna[f][c] == dna[f+2][c+2] and dna[f][c] == dna[f+3][c+3]:
                    print(f"{dna[f][c]}\n {dna[f+1][c+1]}\n  {dna[f+2][c+2]}\n   {dna[f+3][c+3]}")#mostrar coincidencia como referencia
                    l.append(f+1)
                    l.append(c+1)
                    l.append(f+2)
                    l.append(c+2)
                    print("hay coincidencia..")
                    cont+=1
    print("------------DIAGONAL--INVERTIDA-------------")#analiza si hay coincidencias de forma diagonal invertida
    i = []
    for f in range(3):
        for c in range(5,3,-1):
            if f in i and c in i:
                continue
            if dna[f][c] == dna[f+1][c-1] and dna[f][c] == dna[f+2][c-2] and dna[f][c] == dna[f+3][c-3]:
                    print(f"   {dna[f][c]}\n  {dna[f+1][c-1]}\n {dna[f+2][c-2]}\n{dna[f+3][c-3]}")#mostrar coincidencia como referencia
                    i.append(f+1)
                    i.append(c-1)
                    i.append(f+2)
                    i.append(c-2)
                    print("hay coincidencia..")    
                    cont+=1
    print("VERIFICACIÓN MUTANTE O NO ----------------------------")
    if verify(cont) == True:#si es true es mutante
        print(f"se encontró {cont} coincidencias , ES MUTANTE")
    else:
        print(f"se encontró {cont} coincidencias , NO ES MUTANTE")
#-----------------------------------------------------------------
def fill():#rellenar lista con datos ingresados por el usuario
    new_list=[]
    print("Ingrese 6 cadenas de letras A-T-G-C")
    for i in range(6):
        while True:
            text=input("ingrese una cadena de longitud de 6: ")
            if len(text) == 6:#verifica si la cadena es de 6
                new_list.append(text)
                break
            else:
                print("cadena incorrecta:")
    is_mutant(new_list)#llamar funcion para analizar si es mutante o no
#-----------------------------------------------------------------------------
def verify(cont):#retorna true si el contador de las coincidencias es 2 o mas de 2 
    if cont>=2:
        return True
    else:
        return False   