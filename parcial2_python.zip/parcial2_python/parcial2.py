
from fuction import *
not_mutant = [#adn no mutante
        "ATGCGA",
        "CAGTTC",
        "TTCTGT",
        "AGAAGG",
        "CCCCTA",
        "TCACTG"]


dna =  ["ATGCGA",#adn mutante
        "CAGTGC",
        "TTATGT",
        "AGAAGG",
        "CCCCTA",
        "TCACTG"]   
while True:
    print("---MENU---")#menu
    print("Ingrese 1 si desea analizar adn mutante..")
    print("Ingrese 2 si desea analizar adn no mutante..")
    print("Ingrese 3 si desea analizar adn personalizado ingresado por teclado..")
    print("Ingrese 0 si desea salir..")
    option=input("ingrese una opcion: ")
    if option == "1":
        is_mutant(dna)#llama a metodo para analizar adn mutante
    elif option == "2":
        is_mutant(not_mutant)#llama a metodo para analizar adn no mutante
    elif option == "3":
        fill()#llama a metodo para analizar adn personalizado ingresado por el usuario
    else:
        print("Saliendo...")#termina programa
        break

